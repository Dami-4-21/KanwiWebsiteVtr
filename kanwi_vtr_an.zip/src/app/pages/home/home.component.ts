import { Component } from '@angular/core'
import { Title, Meta } from '@angular/platform-browser'

@Component({
  selector: 'app-home',
  templateUrl: 'home.component.html',
  styleUrls: ['home.component.css'],
})
export class Home {
  rawttxd: string = ' '
  rawuahg: string = ' '
  rawwss4: string = ' '
  raw32xg: string = ' '
  raw067h: string = ' '
  rawuamb: string = ' '
  rawj0mu: string = ' '
  rawxldl: string = ' '
  rawduir: string = ' '
  rawk8c1: string = ' '
  constructor(private title: Title, private meta: Meta) {
    this.title.setTitle('Active Online Software Page')
    this.meta.addTags([
      {
        property: 'og:title',
        content: 'Active Online Software Page',
      },
    ])
  }
}
